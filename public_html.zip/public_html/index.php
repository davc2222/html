<?php
// ===== FILE: index.php =====

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$page = $_GET['page'] ?? 'home';

$allowed = [
    'home',
    'search',
    'messages',
    'views',
    'contact',
    'login',
    'register',
    'verify_notice',
    'profile'
];

if (!in_array($page, $allowed, true)) {
    $page = 'home';
}

$page_file = __DIR__ . "/{$page}.php";
?>
<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LoveMatch</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>

<?php
include __DIR__ . '/includes/header.php';
?>

<main class="site-main">
    <?php
    if (file_exists($page_file)) {
        include $page_file;
    } else {
        echo "<div class='page-shell'><p>דף לא נמצא</p></div>";
    }
    ?>
</main>

<?php
include __DIR__ . '/includes/footer.php';
?>

</body>
</html>