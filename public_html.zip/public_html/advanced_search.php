<?php
// ===== FILE: advanced_search.php =====

require_once __DIR__ . '/config/config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function getColumnOptions(PDO $pdo, string $table, string $column): array
{
    $allowed = [
        'religion'         => 'Religion_Str',
        'religion_ref'     => 'Religion_Ref_Str',
        'smoking_habbit'   => 'Smoking_Habbit_Str',
        'drinking_habbit'  => 'Drinking_Habbit_Str',
        'zone'             => 'Zone_Str',
        'family_status'    => 'Family_Status_Str',
        'body_type'        => 'Body_Type_Str',
        'vegitrain'        => 'Vegitrain_Str',
    ];

    if (!isset($allowed[$table]) || $allowed[$table] !== $column) {
        return [];
    }

    try {
        $stmt = $pdo->query("
            SELECT {$column}
            FROM {$table}
            WHERE {$column} IS NOT NULL
              AND {$column} <> ''
            ORDER BY {$column} ASC
        ");

        return $stmt ? $stmt->fetchAll(PDO::FETCH_COLUMN) : [];
    } catch (Throwable $e) {
        return [];
    }
}

function getMainProfileImage(PDO $pdo, int $userId): string
{
    $profileImage = '/images/no_photo.jpg';

    try {
        $picStmt = $pdo->prepare("
            SELECT Pic_Name
            FROM user_pics
            WHERE Id = :id
              AND Main_Pic = 1
              AND Pic_Status = 1
            LIMIT 1
        ");
        $picStmt->execute([':id' => $userId]);
        $picName = $picStmt->fetchColumn();

        if ($picName) {
            $profileImage = '/uploads/' . ltrim((string)$picName, '/');
        }
    } catch (Throwable $e) {
    }

    return $profileImage;
}

function selectedArrayFromSource(array $source, string $key): array
{
    $value = $source[$key] ?? [];
    if (!is_array($value)) {
        return [];
    }

    $clean = [];
    foreach ($value as $item) {
        $item = trim((string)$item);
        if ($item !== '') {
            $clean[] = $item;
        }
    }

    return array_values(array_unique($clean));
}

function jsonArrayOrEmpty($value): array
{
    if ($value === null || $value === '') {
        return [];
    }

    $decoded = json_decode((string)$value, true);
    return is_array($decoded) ? array_values(array_unique(array_map('strval', $decoded))) : [];
}

$viewerId = (int)($_SESSION['user_id'] ?? 0);

/* =========================================
   Load saved preferences
========================================= */
$prefs = null;

if ($viewerId > 0) {
    try {
        $prefsStmt = $pdo->prepare("
            SELECT *
            FROM user_search_preferences
            WHERE user_id = :user_id
            LIMIT 1
        ");
        $prefsStmt->execute([':user_id' => $viewerId]);
        $prefs = $prefsStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        $prefs = null;
    }
}

/* =========================================
   Detect explicit GET search
========================================= */
$hasExplicitSearch = false;
foreach ($_GET as $key => $value) {
    if ($key === 'page') {
        continue;
    }

    if (is_array($value) && !empty($value)) {
        $hasExplicitSearch = true;
        break;
    }

    if (!is_array($value) && trim((string)$value) !== '') {
        $hasExplicitSearch = true;
        break;
    }
}

/* =========================================
   Filters
   Priority:
   1) explicit GET filters
   2) saved preferences from DB
   3) defaults
========================================= */
if ($hasExplicitSearch) {
    $filters = [
        'age_min'        => isset($_GET['age_min']) ? (int)$_GET['age_min'] : 18,
        'age_max'        => isset($_GET['age_max']) ? (int)$_GET['age_max'] : 80,
        'height_min'     => isset($_GET['height_min']) ? (int)$_GET['height_min'] : 140,
        'height_max'     => isset($_GET['height_max']) ? (int)$_GET['height_max'] : 220,
        'children'       => trim((string)($_GET['children'] ?? '')),
        'zone'           => selectedArrayFromSource($_GET, 'zone'),
        'religion'       => selectedArrayFromSource($_GET, 'religion'),
        'religion_ref'   => selectedArrayFromSource($_GET, 'religion_ref'),
        'smoking'        => selectedArrayFromSource($_GET, 'smoking'),
        'drinking'       => selectedArrayFromSource($_GET, 'drinking'),
        'family_status'  => selectedArrayFromSource($_GET, 'family_status'),
        'body_type'      => selectedArrayFromSource($_GET, 'body_type'),
        'vegitrain'      => selectedArrayFromSource($_GET, 'vegitrain'),
    ];
} elseif ($prefs) {
    $filters = [
        'age_min'        => isset($prefs['age_min']) ? (int)$prefs['age_min'] : 18,
        'age_max'        => isset($prefs['age_max']) ? (int)$prefs['age_max'] : 80,
        'height_min'     => isset($prefs['height_min']) ? (int)$prefs['height_min'] : 140,
        'height_max'     => isset($prefs['height_max']) ? (int)$prefs['height_max'] : 220,
        'children'       => trim((string)($prefs['children'] ?? '')),
        'zone'           => jsonArrayOrEmpty($prefs['zone'] ?? null),
        'religion'       => jsonArrayOrEmpty($prefs['religion'] ?? null),
        'religion_ref'   => jsonArrayOrEmpty($prefs['religion_ref'] ?? null),
        'smoking'        => jsonArrayOrEmpty($prefs['smoking'] ?? null),
        'drinking'       => jsonArrayOrEmpty($prefs['drinking'] ?? null),
        'family_status'  => jsonArrayOrEmpty($prefs['family_status'] ?? null),
        'body_type'      => jsonArrayOrEmpty($prefs['body_type'] ?? null),
        'vegitrain'      => jsonArrayOrEmpty($prefs['vegitrain'] ?? null),
    ];
} else {
    $filters = [
        'age_min'        => 18,
        'age_max'        => 80,
        'height_min'     => 140,
        'height_max'     => 220,
        'children'       => '',
        'zone'           => [],
        'religion'       => [],
        'religion_ref'   => [],
        'smoking'        => [],
        'drinking'       => [],
        'family_status'  => [],
        'body_type'      => [],
        'vegitrain'      => [],
    ];
}

if ($filters['age_min'] < 18) {
    $filters['age_min'] = 18;
}
if ($filters['age_max'] > 80) {
    $filters['age_max'] = 80;
}
if ($filters['age_min'] > $filters['age_max']) {
    $filters['age_min'] = $filters['age_max'];
}

if ($filters['height_min'] < 140) {
    $filters['height_min'] = 140;
}
if ($filters['height_max'] > 220) {
    $filters['height_max'] = 220;
}
if ($filters['height_min'] > $filters['height_max']) {
    $filters['height_min'] = $filters['height_max'];
}

$searchShouldRun = $hasExplicitSearch || (bool)$prefs;

/* =========================================
   Options
========================================= */
$zoneOptions        = getColumnOptions($pdo, 'zone', 'Zone_Str');
$religionOptions    = getColumnOptions($pdo, 'religion', 'Religion_Str');
$religionRefOptions = getColumnOptions($pdo, 'religion_ref', 'Religion_Ref_Str');
$smokingOptions     = getColumnOptions($pdo, 'smoking_habbit', 'Smoking_Habbit_Str');
$drinkingOptions    = getColumnOptions($pdo, 'drinking_habbit', 'Drinking_Habbit_Str');
$familyOptions      = getColumnOptions($pdo, 'family_status', 'Family_Status_Str');
$bodyTypeOptions    = getColumnOptions($pdo, 'body_type', 'Body_Type_Str');
$vegitrainOptions   = getColumnOptions($pdo, 'vegitrain', 'Vegitrain_Str');

/* =========================================
   Search
========================================= */
$results = [];

if ($searchShouldRun) {
    $sql = "SELECT * FROM users_profile WHERE 1=1";
    $params = [];

    if ($viewerId > 0) {
        $sql .= " AND Id <> :viewer_id";
        $params[':viewer_id'] = $viewerId;
    }

    $sql .= " AND Age_Computed >= :age_min";
    $params[':age_min'] = $filters['age_min'];

    $sql .= " AND Age_Computed <= :age_max";
    $params[':age_max'] = $filters['age_max'];

    $sql .= " AND Height_Num >= :height_min";
    $params[':height_min'] = $filters['height_min'];

    $sql .= " AND Height_Num <= :height_max";
    $params[':height_max'] = $filters['height_max'];

    $multiMap = [
        'zone'          => 'Zone_Str',
        'religion'      => 'Religion_Str',
        'religion_ref'  => 'Religion_Ref_Str',
        'smoking'       => 'Smoking_Habbit_Str',
        'drinking'      => 'Drinking_Habbit_Str',
        'family_status' => 'Family_Status_Str',
        'body_type'     => 'Body_Type_Str',
        'vegitrain'     => 'Vegitrain_Str',
    ];

    foreach ($multiMap as $filterKey => $dbField) {
        if (!empty($filters[$filterKey])) {
            $inParts = [];

            foreach ($filters[$filterKey] as $i => $value) {
                $paramName = ':' . $filterKey . '_' . $i;
                $inParts[] = $paramName;
                $params[$paramName] = $value;
            }

            if (!empty($inParts)) {
                $sql .= " AND {$dbField} IN (" . implode(',', $inParts) . ")";
            }
        }
    }

    if ($filters['children'] === 'yes') {
        $sql .= " AND Childs_Num_Str IS NOT NULL AND Childs_Num_Str <> '' AND Childs_Num_Str <> '0' AND Childs_Num_Str <> '0 ילדים'";
    } elseif ($filters['children'] === 'no') {
        $sql .= " AND (Childs_Num_Str = '0' OR Childs_Num_Str = '0 ילדים' OR Childs_Num_Str = '' OR Childs_Num_Str IS NULL)";
    }

    $sql .= " ORDER BY Id DESC";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        $results = [];
    }
}

/* =========================================
   Active tags
========================================= */
$activeTags = [];

if ($searchShouldRun) {
    $activeTags[] = 'גילאים: ' . $filters['age_min'] . '-' . $filters['age_max'];
    $activeTags[] = 'גובה: ' . $filters['height_min'] . '-' . $filters['height_max'] . ' ס"מ';

    $tagLabelMap = [
        'zone'          => 'אזור',
        'religion'      => 'דת',
        'religion_ref'  => 'זיקה לדת',
        'smoking'       => 'עישון',
        'drinking'      => 'שתייה',
        'family_status' => 'מצב משפחתי',
        'body_type'     => 'מבנה גוף',
        'vegitrain'     => 'צמחונות',
    ];

    foreach ($tagLabelMap as $key => $label) {
        if (!empty($filters[$key])) {
            $activeTags[] = $label . ': ' . implode(', ', $filters[$key]);
        }
    }

    if ($filters['children'] === 'yes') {
        $activeTags[] = 'ילדים: יש';
    } elseif ($filters['children'] === 'no') {
        $activeTags[] = 'ילדים: אין';
    }
}

$openPanel = !$prefs && !$hasExplicitSearch;
?>

<div class="page-shell advanced-search-shell">
    <div class="advanced-search-header-row">
        <div class="advanced-search-actions">
            <button type="button" class="advanced-search-toggle-btn" id="advancedSearchToggleBtn">
                <?= $openPanel ? 'סגור הגדרות התאמה' : 'ערוך העדפות' ?>
            </button>

            <?php if ($searchShouldRun): ?>
                <a href="/?page=advanced_search&reset=1" class="advanced-search-reset-link">נקה תוצאות</a>
            <?php endif; ?>
        </div>

        <h1 class="advanced-search-page-title">התאמות</h1>
    </div>

    <?php if (!empty($activeTags)): ?>
        <div class="advanced-search-tags">
            <?php foreach ($activeTags as $tag): ?>
                <span class="advanced-search-tag"><?= e($tag) ?></span>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="advanced-search-panel<?= $openPanel ? ' is-open' : '' ?>" id="advancedSearchPanel">
        <form method="POST" action="/save_search_preferences.php" class="advanced-search-form-inline">

            <div class="advanced-search-section advanced-search-section-sliders">
                <div class="advanced-search-slider-box">
                    <div class="advanced-search-slider-head">
                        <h3>טווח גילאים</h3>
                        <div class="advanced-search-slider-values">
                            <span id="ageMinValue"><?= (int)$filters['age_min'] ?></span>
                            <span id="ageMaxValue"><?= (int)$filters['age_max'] ?></span>
                        </div>
                    </div>

                    <div class="advanced-search-slider-wrap">
                        <input type="range" min="18" max="80" value="<?= (int)$filters['age_min'] ?>" id="ageMinRange" name="age_min" class="range-input">
                        <input type="range" min="18" max="80" value="<?= (int)$filters['age_max'] ?>" id="ageMaxRange" name="age_max" class="range-input">
                    </div>
                </div>

                <div class="advanced-search-slider-box">
                    <div class="advanced-search-slider-head">
                        <h3>גובה</h3>
                        <div class="advanced-search-slider-values">
                            <span id="heightMinValue"><?= (int)$filters['height_min'] ?></span>
                            <span id="heightMaxValue"><?= (int)$filters['height_max'] ?></span>
                        </div>
                    </div>

                    <div class="advanced-search-slider-wrap">
                        <input type="range" min="140" max="220" value="<?= (int)$filters['height_min'] ?>" id="heightMinRange" name="height_min" class="range-input">
                        <input type="range" min="140" max="220" value="<?= (int)$filters['height_max'] ?>" id="heightMaxRange" name="height_max" class="range-input">
                    </div>
                </div>
            </div>

            <div class="advanced-search-divider"></div>

            <div class="advanced-search-section-grid">
                <div class="advanced-search-group">
                    <h3>אזור</h3>
                    <div class="advanced-search-checks">
                        <?php foreach ($zoneOptions as $option): ?>
                            <label class="advanced-search-check">
                                <input type="checkbox" name="zone[]" value="<?= e($option) ?>" <?= in_array($option, $filters['zone'], true) ? 'checked' : '' ?>>
                                <span><?= e($option) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="advanced-search-group">
                    <h3>דת</h3>
                    <div class="advanced-search-checks">
                        <?php foreach ($religionOptions as $option): ?>
                            <label class="advanced-search-check">
                                <input type="checkbox" name="religion[]" value="<?= e($option) ?>" <?= in_array($option, $filters['religion'], true) ? 'checked' : '' ?>>
                                <span><?= e($option) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="advanced-search-group">
                    <h3>זיקה לדת</h3>
                    <div class="advanced-search-checks">
                        <?php foreach ($religionRefOptions as $option): ?>
                            <label class="advanced-search-check">
                                <input type="checkbox" name="religion_ref[]" value="<?= e($option) ?>" <?= in_array($option, $filters['religion_ref'], true) ? 'checked' : '' ?>>
                                <span><?= e($option) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="advanced-search-group">
                    <h3>עישון</h3>
                    <div class="advanced-search-checks">
                        <?php foreach ($smokingOptions as $option): ?>
                            <label class="advanced-search-check">
                                <input type="checkbox" name="smoking[]" value="<?= e($option) ?>" <?= in_array($option, $filters['smoking'], true) ? 'checked' : '' ?>>
                                <span><?= e($option) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="advanced-search-group">
                    <h3>שתייה</h3>
                    <div class="advanced-search-checks">
                        <?php foreach ($drinkingOptions as $option): ?>
                            <label class="advanced-search-check">
                                <input type="checkbox" name="drinking[]" value="<?= e($option) ?>" <?= in_array($option, $filters['drinking'], true) ? 'checked' : '' ?>>
                                <span><?= e($option) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="advanced-search-group">
                    <h3>מצב משפחתי</h3>
                    <div class="advanced-search-checks">
                        <?php foreach ($familyOptions as $option): ?>
                            <label class="advanced-search-check">
                                <input type="checkbox" name="family_status[]" value="<?= e($option) ?>" <?= in_array($option, $filters['family_status'], true) ? 'checked' : '' ?>>
                                <span><?= e($option) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="advanced-search-group">
                    <h3>ילדים</h3>
                    <div class="advanced-search-select-wrap">
                        <select name="children" class="advanced-search-select">
                            <option value="" <?= $filters['children'] === '' ? 'selected' : '' ?>>לא משנה</option>
                            <option value="yes" <?= $filters['children'] === 'yes' ? 'selected' : '' ?>>יש</option>
                            <option value="no" <?= $filters['children'] === 'no' ? 'selected' : '' ?>>אין</option>
                        </select>
                    </div>
                </div>

                <div class="advanced-search-group">
                    <h3>מבנה גוף</h3>
                    <div class="advanced-search-checks">
                        <?php foreach ($bodyTypeOptions as $option): ?>
                            <label class="advanced-search-check">
                                <input type="checkbox" name="body_type[]" value="<?= e($option) ?>" <?= in_array($option, $filters['body_type'], true) ? 'checked' : '' ?>>
                                <span><?= e($option) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="advanced-search-group">
                    <h3>צמחונות</h3>
                    <div class="advanced-search-checks">
                        <?php foreach ($vegitrainOptions as $option): ?>
                            <label class="advanced-search-check">
                                <input type="checkbox" name="vegitrain[]" value="<?= e($option) ?>" <?= in_array($option, $filters['vegitrain'], true) ? 'checked' : '' ?>>
                                <span><?= e($option) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <div class="advanced-search-form-actions">
                <a href="/?page=advanced_search&reset=1" class="advanced-search-clear-btn">נקה</a>
                <button type="submit" class="advanced-search-submit-btn">שמור העדפות</button>
            </div>
        </form>
    </div>

    <?php if ($searchShouldRun): ?>
        <div class="advanced-search-results-wrap">
            <?php if (!empty($results)): ?>
                <div class="results">
                    <?php foreach ($results as $user): ?>
                        <?php
                        $userId = (int)($user['Id'] ?? 0);
                        $userName = trim((string)($user['Name'] ?? 'ללא שם'));
                        $userAge = trim((string)($user['Age_Computed'] ?? ''));
                        $userZone = trim((string)($user['Zone_Str'] ?? ''));
                        $userReligion = trim((string)($user['Religion_Str'] ?? ''));
                        $userHeight = trim((string)($user['Height_Str'] ?? ''));
                        $profileImage = getMainProfileImage($pdo, $userId);
                        ?>

                        <div class="search-card-compact advanced-result-card">
                            <img src="<?= e($profileImage) ?>" alt="<?= e($userName) ?>" class="search-card-image">

                            <div class="search-card-content">
                                <div class="search-card-top">
                                    <a href="/?page=profile&id=<?= $userId ?>" class="search-card-link">לצפיה בפרופיל</a>
                                </div>

                                <div class="search-card-title"><?= e($userName) ?></div>

                                <div class="search-card-row">
                                    <?php if ($userAge !== ''): ?><span>גיל: <?= e($userAge) ?></span><?php endif; ?>
                                    <?php if ($userZone !== ''): ?><span>אזור: <?= e($userZone) ?></span><?php endif; ?>
                                    <?php if ($userReligion !== ''): ?><span>דת: <?= e($userReligion) ?></span><?php endif; ?>
                                    <?php if ($userHeight !== ''): ?><span>גובה: <?= e($userHeight) ?></span><?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="advanced-search-empty-box">
                    לא נמצאו תוצאות לפי ההגדרות שבחרת.
                </div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="advanced-search-empty-box">
            עדיין לא הוגדרו העדפות חיפוש. בחר הגדרות ושמור אותן.
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const panel = document.getElementById('advancedSearchPanel');
    const toggleBtn = document.getElementById('advancedSearchToggleBtn');

    if (toggleBtn && panel) {
        toggleBtn.addEventListener('click', function() {
            panel.classList.toggle('is-open');
            toggleBtn.textContent = panel.classList.contains('is-open')
                ? 'סגור הגדרות התאמה'
                : 'ערוך העדפות';
        });
    }

    function bindDualRange(minId, maxId, minOutId, maxOutId) {
        const minInput = document.getElementById(minId);
        const maxInput = document.getElementById(maxId);
        const minOutput = document.getElementById(minOutId);
        const maxOutput = document.getElementById(maxOutId);

        if (!minInput || !maxInput || !minOutput || !maxOutput) {
            return;
        }

        function syncMin() {
            if (parseInt(minInput.value, 10) > parseInt(maxInput.value, 10)) {
                minInput.value = maxInput.value;
            }
            minOutput.textContent = minInput.value;
        }

        function syncMax() {
            if (parseInt(maxInput.value, 10) < parseInt(minInput.value, 10)) {
                maxInput.value = minInput.value;
            }
            maxOutput.textContent = maxInput.value;
        }

        minInput.addEventListener('input', syncMin);
        maxInput.addEventListener('input', syncMax);

        syncMin();
        syncMax();
    }

    bindDualRange('ageMinRange', 'ageMaxRange', 'ageMinValue', 'ageMaxValue');
    bindDualRange('heightMinRange', 'heightMaxRange', 'heightMinValue', 'heightMaxValue');
});
</script>